load('E:\FileRecv\PG1\2022.11\Data\Code\RVFL\Data_4m_Gpick.mat');
train = x;
train_label = y;
seed = 12345678;
rand('seed', seed);

t0 = clock;

train_X = train;
[n,~] = size(train_X);
COM_X = train_X;
train_X_S = line_map(COM_X);
combin = [train_label, train_X_S];
feature_size = size(train_X_S, 2);
N_list = [10:10:150];
lambda1_list = [1, 5, 10, 15, 20, 25, 30, 35, 40, 50];
lambda2_list = [1, 5, 10, 15, 20, 25, 30, 35, 40, 50];
maxT_list = [1, 3, 5];
ratio_list = 2;
args1 = struct('bias', false, 'acfun', 'mix_acfun', 'num', ratio_list);
rul_list = [];
nfolds = 10;
crossval_idx = crossvalind('Kfold', train_label, nfolds);

ind = 0;
for N = N_list
    args2.N = N;
    for lambda1 = lambda1_list
        args2.lambda1 = lambda1;
        for lambda2 = lambda2_list
            args2.lambda2 = lambda2;
            for ratio = ratio_list
                args2.ratio = ratio;
                for maxT = maxT_list
                    args2.maxT = maxT;
                    fold_acc = [];
                    fold_sn = [];
                    fold_sp = [];
                    fold_mcc = [];
                    for fold=1:nfolds
                        train_idx = find(crossval_idx~=fold);
                        test_idx  = find(crossval_idx==fold);
                        
                        test_x = combin(test_idx, 2:feature_size+1);
                        test_y = combin(test_idx, 1);
                        
                        train_x = combin(train_idx, 2:feature_size+1);
                        train_y = combin(train_idx, 1);
                        
                        [~, predict_y] = SSR_RVFL_Gpick(train_x, train_y, test_x, args1, args2);
                        [ACC,SN,Spec,PE,NPV,F_score,MCC] = roc( predict_y, test_y );
                        fold_acc = [fold_acc, ACC];
                        fold_sn = [fold_sn, SN];
                        fold_sp = [fold_sp, Spec];
                        fold_mcc = [fold_mcc, MCC];
                    end
                    ind = ind + 1;
                    rul_list(1, ind) = mean(fold_acc);
                    rul_list(2, ind) = mean(fold_sn);
                    rul_list(3, ind) = mean(fold_sp);
                    rul_list(4, ind) = mean(fold_mcc);
                    rul_list(5, ind) = args2.N;
                    rul_list(6, ind) = args2.lambda1;
                    rul_list(7, ind) = args2.lambda2;
                    rul_list(8, ind) = args2.ratio;
                    rul_list(9, ind) = args2.maxT;
                end
            end
        end
    end
end
[max_acc, ind] = max(rul_list(1, :));

t1 = clock;

fprintf('acc: %f\n', max_acc);
fprintf('sn: %f\n', rul_list(2, ind));
fprintf('sp: %f\n', rul_list(3, ind));
fprintf('mcc: %f\n', rul_list(4, ind));
fprintf('N: %d\n', rul_list(5, ind));
fprintf('lambda1: %f\n', rul_list(6, ind));
fprintf('lambda2: %f\n', rul_list(7, ind));
fprintf('ratio: %f\n', rul_list(8, ind));
fprintf('maxT: %d\n', rul_list(9, ind));
fprintf('activation function: %s\n', args1.acfun);
fprintf('searching time: %f\n', etime(t1,t0));