function [ predict_values, predict_y] = SSR_RVFL_A(train_x, train_y, test_x, args1, args2)
    
        seed = 1;
        randn('state', seed);
        [Nsample, Nfea] = size(train_x);
        bias = args1.bias;
        acfun = args1.acfun;
        num_asp = args1.num+1;  %number of feature sets
        ratio = args2.ratio;
        N = args2.N;
        maxT = args2.maxT;
        lambda1 = args2.lambda1;
        lambda2 = args2.lambda2;
        
        num_classes = length(unique(train_y));
        [multi_labels_y] = y2ooh(train_y, num_classes);
        %training phase-----------------------------------------------------------
        %init the weights and bias of network by Guassian distribution
        weight = randn(Nfea, N);
        bias_g = randn(1, N);
        Bias = repmat(bias_g, Nsample, 1);

        H = train_x * weight + Bias;
        H = mapping(H, acfun, ratio);
        D = H;
        if bias
            D = [D, ones(Nsample, 1)];
        end
        n = size(D, 2);
        D = [D, train_x];
        D(isnan(D)) = 0;  
                
        %structure sparse
        beta = rand(size(D, 2), num_classes);
        for t = 1 : maxT
            W = compute_W21(beta);
            d = compute_D(beta, num_classes, num_asp, n, Nfea, ratio);
            F = D' * D + lambda1 * W;
            G = D' * multi_labels_y;
            for j = 1 : num_classes
                d_j = diag(d(:, j));
                A = (F + lambda2 * d_j);
                beta_j = A \ G(:, j);
                beta(:, j) = beta_j;
            end
        end

        
        %testing phase-----------------------------------------------------------
        [row, ~] = size(test_x);
        beta(find(abs(beta) < 1e-4)) = 0;
        H_test = test_x * weight + repmat(Bias(1, :), row, 1);
        H_test = mapping(H_test, acfun, ratio);
        D = H_test;
        if bias
            D = [D, ones(row, 1)];
        end
        D = [D, test_x];
        D(isnan(D)) = 0;
        
        test_values = D * beta;
        [test_max_values, test_max_index] = max(test_values');
        predict_values = test_max_values';
        predict_y = test_max_index';
        predict_y(find(predict_y == 2)) = -1;
        
end



function Out = mapping(X, acfun, ratio)
    if strcmp(acfun, 'sine')
        miu = 0.0001;
    end
    n = size(X, 2);
    switch lower(acfun)
        case {'sig','sigmoid'}
            X = logsig(X);
        case {'tansig'}
            X = tansig(X);
        case {'radbas'}
            X = radbas(X);
        case {'tribas'}
            X = tribas(X);
        case {'sine'}
            x = find(X<=0);
            X(x) = miu * (sin(X(x)) - cos(X(x)));
        case {'relu'}
            X = max(0, X);
        case {'mix_acfun'}
            for i = 1 : floor(n/ratio)
                X(:,i) = logsig(X(:,i));
            end
            for i = floor(n/ratio)+1 : n
                X(:,i) = tansig(X(:,i));
            end
    end
    Out = X;
end



function [ data_y_ooh ] = y2ooh( y_label, num_classes )

% Transform the labels to the form of 'one-of-hot'  
     n_examples = size(y_label, 1);
     data_y_ooh = zeros(n_examples, num_classes);
     for i=1:n_examples
%        index = y_label(i, :);
        if y_label(i, :) == 1
            index = 1;
        else
            index = 2;
        end
    	data_y_ooh(i, index) = 1;
     end

end



function W = compute_W21(G)

	[n, m] = size(G);
	W = zeros(n, n);
	for s=1:n
           w = 0;
           for t = 1:m
              w = G(s, t)^2 + w;
           end
           w = sqrt(w+1e-7);
           W(s,s) = 1 / w;
	end

end



function D = compute_D(G, num_classes, num_asp, N, Nfea, ratio)
    %structured sparse the matrix G
    n = size(G,1);
    if num_asp == 2
        block = [1, N; N+1, N+Nfea];
    end
    if num_asp == 3
        block = [1, floor(N/ratio); floor(N/ratio)+1, N; N+1, N+Nfea];
    end
    if num_asp == 4
        block = [1, floor(N/ratio); floor(N/ratio)+1, floor(2*N/ratio); floor(2*N/ratio)+1, N; N+1, N+Nfea];
    end
    if num_asp == 5
        block = [1, floor(N/ratio); floor(N/ratio)+1, floor(2*N/ratio); floor(2*N/ratio)+1,...
            floor(3*N/ratio); floor(3*N/ratio)+1, N; N+1, N+Nfea];
    end
    D = zeros(n, num_classes);
    for i = 1 : num_classes
        for j = 1 : num_asp
            end_i = block(j, 2);
            start_i = block(j, 1);
            v = G(start_i: end_i, i);
            v = 2 * norm(v, 2);
            if v == 0
                v = 0.01;
            end
            v = 1 / v;
            V = v * ones(end_i - start_i + 1, 1);
            D(start_i: end_i, i) = V;
        end
    end
    
end




