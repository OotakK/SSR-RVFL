These are the running scripts and functions of SSR-RVFL on the six benchmark datasets. Each dataset has a corresponding running script.

All the experiments have been done on the PC with Window 10 and 8-GB RAM and MATLAB R2016a and Intel Core i5 CPU @2.30GHz processor.